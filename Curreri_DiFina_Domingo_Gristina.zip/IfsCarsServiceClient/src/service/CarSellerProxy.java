package service;

public class CarSellerProxy implements service.CarSeller {
  private String _endpoint = null;
  private service.CarSeller carSeller = null;
  
  public CarSellerProxy() {
    _initCarSellerProxy();
  }
  
  public CarSellerProxy(String endpoint) {
    _endpoint = endpoint;
    _initCarSellerProxy();
  }
  
  private void _initCarSellerProxy() {
    try {
      carSeller = (new service.CarSellerServiceLocator()).getCarSeller();
      if (carSeller != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)carSeller)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)carSeller)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (carSeller != null)
      ((javax.xml.rpc.Stub)carSeller)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public service.CarSeller getCarSeller() {
    if (carSeller == null)
      _initCarSellerProxy();
    return carSeller;
  }
  
  public double convert(java.lang.String currency, double amount) throws java.rmi.RemoteException{
    if (carSeller == null)
      _initCarSellerProxy();
    return carSeller.convert(currency, amount);
  }
  
  public boolean sellVehicle(java.lang.String basket, java.lang.String accountNumber, double amount, java.lang.String currency) throws java.rmi.RemoteException{
    if (carSeller == null)
      _initCarSellerProxy();
    return carSeller.sellVehicle(basket, accountNumber, amount, currency);
  }
  
  public java.lang.String getAvailableForSaleVehicles() throws java.rmi.RemoteException{
    if (carSeller == null)
      _initCarSellerProxy();
    return carSeller.getAvailableForSaleVehicles();
  }
  
  
}