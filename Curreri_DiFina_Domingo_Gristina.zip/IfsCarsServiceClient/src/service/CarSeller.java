/**
 * CarSeller.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package service;

public interface CarSeller extends java.rmi.Remote {
    public double convert(java.lang.String currency, double amount) throws java.rmi.RemoteException;
    public boolean sellVehicle(java.lang.String basket, java.lang.String accountNumber, double amount, java.lang.String currency) throws java.rmi.RemoteException;
    public java.lang.String getAvailableForSaleVehicles() throws java.rmi.RemoteException;
}
